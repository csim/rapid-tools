using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using Rapid.Tools.SPDeploy.AddIn.ProjectFiles.FeatureManifest;
using EnvDTE80;
using System.IO;
using System.Xml;
using System.Net;
using Rapid.Tools.SPDeploy.AddIn.Domain.NodeTags;
using Rapid.Tools.SPDeploy.AddIn.SPToolsWebService;

namespace Rapid.Tools.SPDeploy.AddIn.Domain.NodeTags
{
    public interface INodeTag
    {
        ContextMenu GetContextMenu();
        void Action();
    }   
}
