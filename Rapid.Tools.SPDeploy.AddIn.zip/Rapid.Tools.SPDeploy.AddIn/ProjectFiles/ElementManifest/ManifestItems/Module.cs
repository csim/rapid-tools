using System;
using System.Collections.Generic;
using System.Text;

namespace Rapid.Tools.SPDeploy.AddIn.ProjectFiles.ElementManifest.ManifestItems
{
    class Module
    {
    }
}
