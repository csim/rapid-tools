using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;

namespace [REPLACEPROJECTNAME].Receivers
{
    public class [REPLACECLASSNAME] : SPFeatureReceiver
    {

        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
        }

        public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        {
        }

        public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        {
        }

        public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        {
        }
    }
}
