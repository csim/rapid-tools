using System;
using System.Web.UI;

[assembly: WebResource(@"[REPLACEPROJECTNAME].Web.UI.WebControls.WebPartResources.HelloScript.js", @"text/javascript")]

